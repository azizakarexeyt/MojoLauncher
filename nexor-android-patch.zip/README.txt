NexorMC Android (MojoLauncher forku) - UYGULANMAMIS/DERLENMEMIS yama

1) GitHub'da MojoLauncher'i fork'la (LGPLv3: kaynak acik kalmali).
2) Bu zip'teki "patch/app_mojo" klasorunu fork'un app_mojo klasorunun uzerine kopyala (ayni yollar uzerine yazar).
3) Nexor Client jar'ini app_mojo/src/main/assets/nexor/ icine koy (opsiyonel).
4) Logo: res/mipmap-*/ic_launcher* dosyalarini Nexor logosuyla degistir.
5) Actions > Android workflow calistir (assembleFullDebug) -> APK artifact.
Yeni: ana menude "NEXORMC'YE GIR" (Fabric 1.21.11 + fabric-api, lithium, ferrite-core, entityculling kurar, nexormc.marthost.net'e otomatik girer) ve "Modlari yenile".
Oyun -Dnexor.platform=mobile ile acilir (rozet icin client mod bunu okuyabilir).
