package git.artdeell.mojo;

import android.app.Activity;
import android.widget.Toast;

import git.artdeell.mojo.extra.ExtraConstants;
import git.artdeell.mojo.extra.ExtraCore;
import git.artdeell.mojo.instances.Instance;
import git.artdeell.mojo.instances.Instances;
import git.artdeell.mojo.modding.fabric.FabricVersion;
import git.artdeell.mojo.modding.fabric.FabriclikeUtils;
import git.artdeell.mojo.utils.DownloadUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.io.FileOutputStream;

/** NexorMC: tek dokunusla Fabric 1.21.11 + optimizasyon modlari + sunucuya otomatik giris. */
public class NexorSetup {
    public static final String SERVER_IP = "nexormc.marthost.net";
    public static final String MC_VERSION = "1.21.11";
    public static final String MARKER = ".nexor";
    private static final String[] MODS = {"fabric-api", "lithium", "ferrite-core", "entityculling"};
    private static boolean sRunning;

    public static boolean isNexorDir(File gameDir) {
        return new File(gameDir, MARKER).exists();
    }

    /** @param refreshOnly true ise sadece modlari yeniler, oyunu baslatmaz */
    public static synchronized void run(Activity activity, boolean refreshOnly) {
        if(sRunning) return;
        sRunning = true;
        Tools.runOnUiThread(() -> Toast.makeText(activity, "Nexor hazirlaniyor...", Toast.LENGTH_SHORT).show());
        MojoApplication.sExecutorService.execute(() -> {
            try {
                Instance inst = ensureInstance();
                File mods = new File(inst.getGameDirectory(), "mods");
                if(!mods.isDirectory() && !mods.mkdirs()) throw new IOException("mods klasoru acilamadi");
                syncMods(mods, activity.getApplicationContext());
                Tools.runOnUiThread(() -> Toast.makeText(activity,
                        refreshOnly ? "Modlar yenilendi" : "Baslatiliyor", Toast.LENGTH_SHORT).show());
                if(!refreshOnly) ExtraCore.setValue(ExtraConstants.LAUNCH_GAME, true);
            } catch (Exception e) {
                Tools.showErrorRemote(e);
            } finally {
                sRunning = false;
            }
        });
    }

    private static Instance ensureInstance() throws IOException {
        for(Instance i : Instances.loadAllInstances()) {
            if(isNexorDir(i.getGameDirectory()) && i.versionId != null) {
                Instances.setSelectedInstance(i);
                return i;
            }
        }
        FabricVersion[] loaders = FabriclikeUtils.FABRIC_UTILS.downloadLoaderVersions(MC_VERSION);
        if(loaders == null || loaders.length == 0) throw new IOException("Fabric surumleri okunamadi");
        String loader = loaders[0].version;
        for(FabricVersion v : loaders) if(v.stable) { loader = v.version; break; }
        String versionId = FabriclikeUtils.FABRIC_UTILS.install(MC_VERSION, loader);
        if(versionId == null) throw new IOException("Fabric kurulamadi");
        Instance created = Instances.createInstance(i -> {
            i.name = "NexorMC";
            i.icon = FabriclikeUtils.FABRIC_UTILS.getIconName();
            i.versionId = versionId;
        }, "NexorMC");
        File marker = new File(created.getGameDirectory(), MARKER);
        File dir = created.getGameDirectory();
        if(!dir.isDirectory() && !dir.mkdirs()) throw new IOException("oyun klasoru acilamadi");
        if(!marker.createNewFile() && !marker.exists()) throw new IOException("isaret dosyasi yazilamadi");
        Instances.setSelectedInstance(created);
        return created;
    }

    private static void syncMods(File modsDir, android.content.Context ctx) throws IOException {
        for(String slug : MODS) {
            try {
                installFromModrinth(slug, modsDir);
            } catch (Exception e) {
                android.util.Log.w("NexorSetup", "mod atlandi: " + slug, e);
            }
        }
        copyBundled(modsDir, ctx);
    }

    private static void installFromModrinth(String slug, File modsDir) throws Exception {
        String q = "?game_versions=" + URLEncoder.encode("[\"" + MC_VERSION + "\"]", "UTF-8")
                + "&loaders=" + URLEncoder.encode("[\"fabric\"]", "UTF-8");
        JSONArray versions = new JSONArray(DownloadUtils.downloadString(
                "https://api.modrinth.com/v2/project/" + slug + "/version" + q));
        if(versions.length() == 0) return;
        JSONArray files = versions.getJSONObject(0).getJSONArray("files");
        JSONObject file = files.getJSONObject(0);
        for(int i = 0; i < files.length(); i++) {
            if(files.getJSONObject(i).optBoolean("primary")) { file = files.getJSONObject(i); break; }
        }
        String name = file.getString("filename");
        File out = new File(modsDir, name);
        if(out.isFile() && out.length() > 0) return;
        File[] old = modsDir.listFiles((d, n) -> n.startsWith(slug + "-") && n.endsWith(".jar"));
        if(old != null) for(File f : old) { boolean ignored = f.delete(); }
        DownloadUtils.downloadFile(file.getString("url"), out);
    }

    /** assets/nexor/ icindeki jar dosyalarini (Nexor Client) mods klasorune kopyalar. */
    private static void copyBundled(File modsDir, android.content.Context ctx) throws IOException {
        android.content.res.AssetManager am = ctx.getAssets();
        String[] list = am.list("nexor");
        if(list == null) return;
        for(String n : list) {
            if(!n.endsWith(".jar")) continue;
            File[] old = modsDir.listFiles((d, f) -> f.startsWith("nexor-client-") && f.endsWith(".jar"));
            if(old != null) for(File f : old) { boolean ignored = f.delete(); }
            try (InputStream in = am.open("nexor/" + n); OutputStream os = new FileOutputStream(new File(modsDir, n))) {
                byte[] buf = new byte[8192];
                int r;
                while((r = in.read(buf)) > 0) os.write(buf, 0, r);
            }
        }
    }
}
